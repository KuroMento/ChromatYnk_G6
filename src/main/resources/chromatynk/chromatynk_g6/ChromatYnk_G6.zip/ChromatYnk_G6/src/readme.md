Welcome to our application.

This application reads a list of inputs and print the according drawing following the instructions.
The list of instruction can be found on the right of the application on launch.
If there are any mistakes in the instruction, an error will be returned explaining why it doesn't work. Otherwise, the application should draw as required.

There are two ways of reading instructions : 
- writing them in the command prompt of the application 
- loading them with a file (the file needs to be on the .lynk format).

In the settings, the execution speed can be chosen (default speed is 1).

Authors :
-Olivier Compagnon--Minarro
-Clément Delamotte
-Matthias Franchini
-Célian Mignot
-Hénoch Xu

ING1 GI3 - G6