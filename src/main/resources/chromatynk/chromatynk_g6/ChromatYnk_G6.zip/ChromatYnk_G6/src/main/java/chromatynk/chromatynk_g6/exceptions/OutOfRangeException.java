package chromatynk.chromatynk_g6.exceptions;

public class OutOfRangeException extends Exception{
    public OutOfRangeException(){
        super();
    }
    public OutOfRangeException(String s){
        super(s);
    }
}
