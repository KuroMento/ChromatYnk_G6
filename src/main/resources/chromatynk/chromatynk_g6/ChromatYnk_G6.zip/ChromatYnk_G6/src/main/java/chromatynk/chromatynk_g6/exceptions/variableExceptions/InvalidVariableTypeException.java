package chromatynk.chromatynk_g6.exceptions.variableExceptions;

public class InvalidVariableTypeException extends Exception{
    public InvalidVariableTypeException(){
        super();
    }
    public InvalidVariableTypeException(String s){
        super(s);
    }
}
