package chromatynk.chromatynk_g6.exceptions.cursorExceptions;

public class InvalidColorException extends Exception{
    public InvalidColorException(){
        super();
    }
    public InvalidColorException(String msg){
        super(msg);
    }
}
