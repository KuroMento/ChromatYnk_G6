package chromatynk.chromatynk_g6.exceptions;

public class NegativeNumberException extends Exception{
    public NegativeNumberException(){
        super();
    }

    public NegativeNumberException(String s){
        super(s);
    }
}
