package chromatynk.chromatynk_g6.diagnostic;

/**
 * An enumeration for <code>{@link LYnkIssue}</code>'s type recognition.
 */
public enum IssueType {
    WARNING,
    ERROR
}
