package chromatynk.chromatynk_g6.statements;

import chromatynk.chromatynk_g6.interpreter.LYnkVariableImpl;

/**
 * A STRING declaration's representation
 */
public class StringDeclaration extends Statement {
    private String variableName;
    private String expression;

    /** constructor
     *
     * @param variableName
     * @param expression
     * @param varContext
     */
    public StringDeclaration(String variableName, String expression, LYnkVariableImpl varContext){
        super("STR", varContext);
        this.variableName = variableName;
        this.expression = expression;
    }

    /** constructor
     *
     * @param variableName
     * @param varContext
     */
    public StringDeclaration(String variableName, LYnkVariableImpl varContext){
        super("STR", varContext);
        this.variableName = variableName;
        this.expression = "";
    }


    public String getVariableName() {
        return variableName;
    }

    public String getExpression() {
        return expression;
    }
    /**
     * This method convert to a String and return it
     * @return
     */
    @Override
    public String toString() {
        return super.toString() + " " + this.variableName + " = " + this.expression.toString() + "\n";
    }
}