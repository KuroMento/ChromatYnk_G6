package chromatynk.chromatynk_g6.exceptions;

public class InvalidInputException extends Exception{
    public InvalidInputException(String s){
        super(s);
    }
}
