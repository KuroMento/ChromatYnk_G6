package chromatynk.chromatynk_g6.interpreter;

public abstract class Variable {
}
