package chromatynk.chromatynk_g6.exceptions;

public class InvalidSymbolException extends Exception{
    public InvalidSymbolException(String s){
        super(s);
    }
}
