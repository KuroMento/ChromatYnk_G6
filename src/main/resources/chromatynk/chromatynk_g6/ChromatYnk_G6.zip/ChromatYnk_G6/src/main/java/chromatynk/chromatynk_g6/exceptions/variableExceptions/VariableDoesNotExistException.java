package chromatynk.chromatynk_g6.exceptions.variableExceptions;

public class VariableDoesNotExistException extends Exception{
    public VariableDoesNotExistException(){
        super();
    }
    public VariableDoesNotExistException(String s){
        super(s);
    }
}
